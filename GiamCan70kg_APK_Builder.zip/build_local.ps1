# Script tu dong dong goi APK tren Windows (neu co Node.js)
Write-Host "Dang cai dat cong cu Capacitor dong goi APK..." -ForegroundColor Green
npm init -y
npm install @capacitor/core @capacitor/cli @capacitor/android
New-Item -ItemType Directory -Force -Path "www"
Copy-Item "index.html" -Destination "www\index.html"
npx cap init "GiamCan70kg" "com.dung.giamcan70kg" --web-dir www
npx cap add android
npx cap sync android
npx cap open android
Write-Host "Da mo Android Studio! Nhan 'Build > Build APK' de lay file .apk" -ForegroundColor Green
