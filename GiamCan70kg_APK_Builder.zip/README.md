# Dự Án Đóng Gói APK - Lộ Trình Giảm Cân 79kg -> 70kg

### Cách lấy file .APK nhanh nhất (Không cần cài Android Studio):
1. Đưa toàn bộ thư mục này lên một **GitHub Repository** cá nhân của bạn (public hoặc private).
2. Vào tab **Actions** trên GitHub Repo.
3. Chọn workflow **Build Android APK** và bấm **Run workflow**.
4. Sau khoảng 2-3 phút, GitHub sẽ biên dịch tự động trên máy chủ Ubuntu có đầy đủ Android SDK/Gradle và xuất ra file **`App-Giam-Can-70kg.apk`** trong mục **Artifacts** để bạn tải về điện thoại cài đặt!
